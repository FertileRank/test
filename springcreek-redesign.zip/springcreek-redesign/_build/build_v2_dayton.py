# -*- coding: utf-8 -*-
"""Build the Dayton (Centerville) Brand v2 location page to match the attached
Columbus/Cincinnati pages (no Dayton file was provided)."""
import os, re, sys
sys.path.insert(0, "/tmp/scfbuild")
import common, build_v2

col = open("/tmp/scfbuild/_columbus_transformed.html", encoding="utf-8").read()
PREFIX = re.search(r'(<div class="scl">\s*<style>.*?</style>)', col, re.S).group(1)

PIN = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>'
PHONE = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>'
CLOCK = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
ARROW = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'
NAVIG = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l19-9-9 19-2-8-8-2z"/></svg>'
STAR = '<svg class="scl-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.9 6.3 6.9.6-5.2 4.5 1.6 6.7L12 16.9 5.8 20.6l1.6-6.7L2.2 8.9l6.9-.6z"/></svg>'
CAL = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>'
CHECK = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>'
LAB = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 2v6l-5 9a2 2 0 0 0 1.8 3h12.4a2 2 0 0 0 1.8-3l-5-9V2"/><path d="M8 2h8"/></svg>'
HEART = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>'
TREE = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v20M5 8l7-4 7 4M5 16l7 4 7-4"/></svg>'
DROP = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 3 2 5 2 7h10c0-2 2-4 2-7a7 7 0 0 0-7-7z"/><path d="M9 21h6"/></svg>'
USERS = '<svg class="scl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>'

INNER = '''
<!-- BREADCRUMB -->
<nav class="scl-breadcrumb" aria-label="Breadcrumb"><div class="scl-wrap"><ol>
  <li><a href="https://www.springcreekfertility.com/">Home</a></li>
  <li><a href="https://www.springcreekfertility.com/locations/">Locations</a></li>
  <li aria-current="page">Dayton</li>
</ol></div></nav>

<!-- HERO -->
<header class="scl-hero"><div class="scl-wrap">
  <span class="scl-eyebrow"><span class="dot"></span> SpringCreek Fertility &middot; Dayton (Centerville), Ohio</span>
  <h1>Dayton Fertility Specialists in <em>Centerville, Ohio</em></h1>
  <p class="scl-lead">Where SpringCreek began. Our founding center in Centerville is home to our on-site <strong>IVF laboratory</strong> and a full range of <strong>fertility treatment in Dayton</strong> &mdash; advanced reproductive care delivered with genuine, personal support.</p>
  <div class="scl-trust">
    <span class="i"><span class="scl-stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</span> <b>4.5</b>&nbsp;&middot; 175+ Google reviews</span>
    <span class="i">&#127973; <b>Physician-owned</b></span>
    <span class="i">&#128205; Serving the Miami Valley since 2014</span>
  </div>
  <div class="scl-cta-row">
    <a class="scl-btn scl-btn--primary" href="https://www.springcreekfertility.com/appointment/">Schedule a Consultation ''' + ARROW + '''</a>
    <a class="scl-btn scl-btn--light" href="tel:+19374585084">''' + PHONE + ''' Call (937) 458-5084</a>
  </div>
  <div class="scl-keyfacts">
    <p><strong>SpringCreek Fertility&rsquo;s Dayton center</strong> is located at <strong>7095 Clyo Road, Dayton (Centerville), OH 45459</strong>, just off I-675. As our founding location and the home of our on-site IVF laboratory, the Dayton center offers fertility evaluations, IUI, IVF, and egg freezing, open Monday&ndash;Friday, 7:00&nbsp;AM&ndash;4:00&nbsp;PM.</p>
    <dl class="scl-facts">
      <div><dt>Address</dt><dd>7095 Clyo Road, Dayton (Centerville), OH 45459</dd></div>
      <div><dt>Phone</dt><dd><a href="tel:+19374585084">(937) 458-5084</a></dd></div>
      <div><dt>Hours</dt><dd>Mon&ndash;Fri, 7:00 AM &ndash; 4:00 PM</dd></div>
      <div><dt>Specialties</dt><dd>IVF &middot; ICSI &middot; IUI &middot; Egg Freezing &middot; On-site Lab</dd></div>
      <div><dt>Serving</dt><dd>Centerville, Kettering, Beavercreek, Springboro &amp; the Miami Valley</dd></div>
    </dl>
  </div>
</div></header>

<!-- INTRO + INFO/MAP -->
<section class="scl-section"><div class="scl-wrap">
  <span class="scl-kicker">Welcome to SpringCreek Dayton</span>
  <h2>Our founding center &mdash; with an on-site IVF laboratory</h2>
  <p class="intro">SpringCreek Fertility was founded in Dayton in 2014, and our Centerville center remains the heart of the practice. Here, reproductive endocrinology, cycle monitoring, and our own on-site IVF laboratory come together under one roof &mdash; so your physician and our embryology team coordinate your care closely, from evaluation through every step that follows. Early-morning hours make it easier to fit monitoring around work and family.</p>
  <div class="scl-info__grid">
    <div class="scl-card">
      <h3>''' + PIN + ''' Visit the Dayton Center</h3>
      <address><strong>SpringCreek Fertility</strong><br>7095 Clyo Road<br>Dayton (Centerville), OH 45459</address>
      <p class="scl-sub">Just off I-675 in the Centerville/Washington Township area &mdash; convenient to Kettering, Beavercreek, and Springboro, with on-site parking.</p>
      <div class="scl-inline-cta">
        <a class="scl-mini" href="https://www.google.com/maps/dir/?api=1&destination=7095+Clyo+Road,+Dayton,+OH+45459">''' + NAVIG + ''' Get Directions</a>
        <a class="scl-mini" href="https://www.google.com/maps?q=SpringCreek+Fertility,+7095+Clyo+Road,+Dayton,+OH+45459">''' + STAR + ''' Read Google Reviews</a>
      </div>
    </div>
    <div class="scl-card">
      <h3>''' + CLOCK + ''' Hours &amp; Contact</h3>
      <table class="scl-hours">
        <tr><th scope="row">Monday &ndash; Friday</th><td>7:00 AM &ndash; 4:00 PM</td></tr>
        <tr><th scope="row">Saturday</th><td class="closed">Closed</td></tr>
        <tr><th scope="row">Sunday</th><td class="closed">Closed</td></tr>
      </table>
      <p class="scl-sub" style="margin-top:16px">New &amp; existing patients: <a href="tel:+19374585084"><strong>(937) 458-5084</strong></a><br>An appointment is required &mdash; early-morning monitoring slots help you fit care around work.</p>
      <div class="scl-inline-cta"><a class="scl-mini" href="https://www.springcreekfertility.com/appointment/">''' + CAL + ''' Book Online</a></div>
    </div>
  </div>
  <div class="scl-map"><iframe title="Map to SpringCreek Fertility, 7095 Clyo Road, Dayton, OH 45459" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=SpringCreek%20Fertility,%207095%20Clyo%20Road,%20Dayton,%20OH%2045459&output=embed"></iframe></div>
</div></section>

<!-- SERVICES -->
<section class="scl-section scl-section--soft"><div class="scl-wrap">
  <span class="scl-kicker">Fertility Treatment in Dayton</span>
  <h2>A full continuum of fertility care for the Miami Valley</h2>
  <p class="intro">From your first questions through advanced treatment, our Dayton center offers every option you need under one trusted, physician-led practice &mdash; supported by our on-site IVF laboratory.</p>
  <div class="scl-grid-3">
    <article class="scl-service"><div class="scl-service__ic">''' + CHECK + '''</div><h3>In Vitro Fertilization (IVF &amp; ICSI)</h3><p>Advanced IVF, with ICSI when helpful, performed and cultured in our on-site embryology laboratory.</p></article>
    <article class="scl-service"><div class="scl-service__ic">''' + HEART + '''</div><h3>Intrauterine Insemination (IUI)</h3><p>An effective, less-involved first step, timed precisely to your cycle with on-site monitoring.</p></article>
    <article class="scl-service"><div class="scl-service__ic">''' + TREE + '''</div><h3>Fertility Evaluation &amp; Testing</h3><p>Clear, comprehensive testing for both partners to pinpoint a path forward.</p></article>
    <article class="scl-service"><div class="scl-service__ic">''' + DROP + '''</div><h3>Egg &amp; Embryo Freezing</h3><p>Plan ahead on your timeline with advanced vitrification for fertility preservation.</p></article>
    <article class="scl-service"><div class="scl-service__ic">''' + LAB + '''</div><h3>On-site IVF Laboratory</h3><p>Embryology, fertilization, freezing, and genetic-testing coordination, all within our practice.</p></article>
    <article class="scl-service"><div class="scl-service__ic">''' + USERS + '''</div><h3>Donor &amp; Third-Party</h3><p>Supportive guidance through egg donation, sperm donation, and gestational surrogacy options.</p></article>
  </div>
</div></section>

<!-- WHY -->
<section class="scl-section"><div class="scl-wrap">
  <span class="scl-kicker">Why Dayton Families Choose SpringCreek</span>
  <h2>Physician-owned care, built around Miami Valley families</h2>
  <div class="scl-why__grid">
    <div class="scl-feature"><div class="scl-feature__ic">''' + CHECK + '''</div><div><h3>Our own on-site IVF laboratory</h3><p>Keeping embryology in-house means your care team and our scientists work side by side &mdash; coordinated, consistent, and close to home.</p></div></div>
    <div class="scl-feature"><div class="scl-feature__ic">''' + STAR + '''</div><div><h3>Where SpringCreek began</h3><p>Founded in Dayton in 2014, our Centerville center brings more than a decade of experience and a deep commitment to this community.</p></div></div>
    <div class="scl-feature"><div class="scl-feature__ic">''' + NAVIG + '''</div><div><h3>Easy to reach off I-675</h3><p>A convenient Centerville location with on-site parking &mdash; close for Kettering, Beavercreek, Springboro, and beyond.</p></div></div>
    <div class="scl-feature"><div class="scl-feature__ic">''' + HEART + '''</div><div><h3>Inclusive &amp; affirming</h3><p>An LGBTQ+ friendly, welcoming clinic supporting every family-building journey with respect.</p></div></div>
  </div>
</div></section>

<!-- TEAM -->
<section class="scl-section scl-section--cream"><div class="scl-wrap">
  <span class="scl-kicker">Meet Your Dayton Fertility Specialists</span>
  <h2>Board-certified reproductive endocrinologists</h2>
  <p class="intro">SpringCreek patients across the Miami Valley are cared for by physicians who specialize exclusively in reproductive endocrinology and infertility.</p>
  <div class="scl-team__grid">
    <article class="scl-doc">
      <h3 class="scl-doc__name">Jeremy Groll, MD</h3>
      <span class="scl-doc__role">Founder &amp; Medical Director &middot; Reproductive Endocrinologist</span>
      <p>Founder of SpringCreek Fertility (2014) and double board-certified in Reproductive Endocrinology &amp; Infertility and Obstetrics &amp; Gynecology, Dr. Groll leads the practice and its on-site IVF laboratory with a patient-first philosophy. <a href="https://www.springcreekfertility.com/doctor-jeremy-groll/">Learn more &rarr;</a></p>
    </article>
    <article class="scl-doc">
      <h3 class="scl-doc__name">Kasey Marelić, MD</h3>
      <span class="scl-doc__role">Reproductive Endocrinologist</span>
      <p>Double board-certified in Obstetrics &amp; Gynecology and Reproductive Endocrinology &amp; Infertility, Dr. Marelić partners with patients through evaluation and treatment with clarity, empathy, and individualized care. <a href="https://www.springcreekfertility.com/dr-kasey-marelic/">Learn more &rarr;</a></p>
    </article>
  </div>
</div></section>

<!-- SERVICE AREA -->
<section class="scl-section"><div class="scl-wrap">
  <span class="scl-kicker">Serving Greater Dayton</span>
  <h2>Fertility care for Dayton &amp; the Miami Valley</h2>
  <p class="intro">Our Centerville center welcomes hopeful parents from across the greater Dayton region, including:</p>
  <div class="scl-chips">
    <span class="scl-chip">Dayton</span><span class="scl-chip">Centerville</span><span class="scl-chip">Kettering</span>
    <span class="scl-chip">Beavercreek</span><span class="scl-chip">Springboro</span><span class="scl-chip">Oakwood</span>
    <span class="scl-chip">Bellbrook</span><span class="scl-chip">Miamisburg</span><span class="scl-chip">Huber Heights</span>
    <span class="scl-chip">Vandalia</span><span class="scl-chip">Fairborn</span><span class="scl-chip">Xenia</span>
    <span class="scl-chip">Troy</span><span class="scl-chip">Springfield</span>
  </div>
</div></section>

<!-- FAQ -->
<section class="scl-section scl-section--soft"><div class="scl-wrap">
  <span class="scl-kicker" style="display:inline-flex">Questions, Answered</span>
  <h2 style="max-width:none">Dayton fertility clinic FAQs</h2>
  <div class="scl-faq">
    <details class="scl-faq__item" open><summary>Where is SpringCreek&rsquo;s Dayton fertility clinic located?</summary><div class="scl-faq__a"><p>Our Dayton center is at <strong>7095 Clyo Road, Dayton (Centerville), OH 45459</strong>, just off I-675 with on-site parking. Call <a href="tel:+19374585084">(937) 458-5084</a> to schedule.</p></div></details>
    <details class="scl-faq__item"><summary>Is the IVF laboratory located in Dayton?</summary><div class="scl-faq__a"><p>Yes. SpringCreek&rsquo;s on-site IVF laboratory operates from the Dayton center, where egg retrievals, fertilization, embryo culture, and cryopreservation are performed and coordinated with your care team.</p></div></details>
    <details class="scl-faq__item"><summary>Which areas does the Dayton center serve?</summary><div class="scl-faq__a"><p>Patients travel to our Dayton center from Centerville, Kettering, Beavercreek, Springboro, Oakwood, Bellbrook, Miamisburg, Huber Heights, Troy, and across Montgomery County and the greater Miami Valley.</p></div></details>
    <details class="scl-faq__item"><summary>Do I need a referral to see a Dayton fertility specialist?</summary><div class="scl-faq__a"><p>No referral is required &mdash; you can book directly. We also welcome referrals from area OB-GYNs and primary care providers. Because fertility coverage varies, we suggest confirming your insurance benefits before your first visit.</p></div></details>
    <details class="scl-faq__item"><summary>When should I schedule a fertility consultation?</summary><div class="scl-faq__a"><p>Consider an evaluation if you&rsquo;re under 35 and have been trying to conceive for 12 months, or 6 months if you&rsquo;re 35 or older. Reach out sooner with irregular cycles, conditions such as PCOS or endometriosis, prior losses, or to plan ahead with egg freezing.</p></div></details>
  </div>
</div></section>

<!-- CTA -->
<section aria-label="Schedule a consultation"><div class="scl-cta">
  <h2>Start your family-building journey in Dayton</h2>
  <p>Compassionate, physician-led fertility care &mdash; with an on-site IVF laboratory &mdash; is close to home. Book a consultation at our Centerville center and take the next hopeful step with specialists who truly listen.</p>
  <div class="scl-cta-row">
    <a class="scl-btn scl-btn--primary" href="https://www.springcreekfertility.com/appointment/">Schedule a Consultation</a>
    <a class="scl-btn scl-btn--light" href="tel:+19374585084">Call (937) 458-5084</a>
  </div>
</div></section>

<div class="scl-disclaimer"><p>SpringCreek Fertility &middot; Dayton (Centerville) &middot; The information on this page is for general educational purposes and is not a substitute for personalized medical advice. Treatment options and outcomes vary by individual; please consult our physicians to discuss your specific situation.</p></div>

<!-- STRUCTURED DATA (JSON-LD) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": ["MedicalClinic","MedicalBusiness"],
      "@id": "https://www.springcreekfertility.com/dayton-fertility-center/#clinic",
      "name": "SpringCreek Fertility — Dayton (Centerville)",
      "url": "https://www.springcreekfertility.com/dayton-fertility-center/",
      "telephone": "+1-937-458-5084", "faxNumber": "+1-937-458-5089", "priceRange": "$$",
      "medicalSpecialty": "Gynecologic",
      "parentOrganization": { "@type": "MedicalOrganization", "name": "SpringCreek Fertility", "url": "https://www.springcreekfertility.com/" },
      "address": { "@type": "PostalAddress", "streetAddress": "7095 Clyo Road", "addressLocality": "Dayton", "addressRegion": "OH", "postalCode": "45459", "addressCountry": "US" },
      "geo": { "@type": "GeoCoordinates", "latitude": "39.6219", "longitude": "-84.1480" },
      "hasMap": "https://www.google.com/maps?q=SpringCreek+Fertility,+7095+Clyo+Road,+Dayton,+OH+45459",
      "areaServed": [
        {"@type":"City","name":"Dayton"}, {"@type":"City","name":"Centerville"}, {"@type":"City","name":"Kettering"},
        {"@type":"City","name":"Beavercreek"}, {"@type":"City","name":"Springboro"}, {"@type":"AdministrativeArea","name":"Montgomery County"}
      ],
      "openingHoursSpecification": [ {"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"07:00","closes":"16:00"} ],
      "aggregateRating": {"@type":"AggregateRating","ratingValue":"4.5","reviewCount":"177","bestRating":"5"},
      "sameAs": [
        "https://www.facebook.com/SpringCreekFertility",
        "https://www.instagram.com/springcreek_fertility/",
        "https://www.linkedin.com/company/springcreek-fertility/",
        "https://www.youtube.com/channel/UC9j44LjwMOgALcv6LyLtv9A"
      ],
      "employee": [
        {"@type":"Physician","name":"Jeremy Groll, MD","medicalSpecialty":"Gynecologic","url":"https://www.springcreekfertility.com/doctor-jeremy-groll/"},
        {"@type":"Physician","name":"Kasey Marelić, MD","medicalSpecialty":"Gynecologic","url":"https://www.springcreekfertility.com/dr-kasey-marelic/"}
      ],
      "availableService": [
        {"@type":"MedicalProcedure","name":"In Vitro Fertilization (IVF)"},
        {"@type":"MedicalProcedure","name":"Intracytoplasmic Sperm Injection (ICSI)"},
        {"@type":"MedicalProcedure","name":"Intrauterine Insemination (IUI)"},
        {"@type":"MedicalTest","name":"Fertility Evaluation and Testing"},
        {"@type":"MedicalProcedure","name":"Egg Freezing"},
        {"@type":"MedicalProcedure","name":"Embryo Freezing"},
        {"@type":"MedicalProcedure","name":"Egg Donation & Third-Party Reproduction"}
      ]
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {"@type":"ListItem","position":1,"name":"Home","item":"https://www.springcreekfertility.com/"},
        {"@type":"ListItem","position":2,"name":"Locations","item":"https://www.springcreekfertility.com/locations/"},
        {"@type":"ListItem","position":3,"name":"Dayton","item":"https://www.springcreekfertility.com/dayton-fertility-center/"}
      ]
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {"@type":"Question","name":"Where is SpringCreek's Dayton fertility clinic located?","acceptedAnswer":{"@type":"Answer","text":"Our Dayton center is at 7095 Clyo Road, Dayton (Centerville), OH 45459, just off I-675 with on-site parking. Call (937) 458-5084 to schedule."}},
        {"@type":"Question","name":"Is the IVF laboratory located in Dayton?","acceptedAnswer":{"@type":"Answer","text":"Yes. SpringCreek's on-site IVF laboratory operates from the Dayton center, where egg retrievals, fertilization, embryo culture, and cryopreservation are performed and coordinated with your care team."}},
        {"@type":"Question","name":"Which areas does the Dayton center serve?","acceptedAnswer":{"@type":"Answer","text":"Patients travel to our Dayton center from Centerville, Kettering, Beavercreek, Springboro, Oakwood, Bellbrook, Miamisburg, Huber Heights, Troy, and across Montgomery County and the greater Miami Valley."}},
        {"@type":"Question","name":"Do I need a referral to see a Dayton fertility specialist?","acceptedAnswer":{"@type":"Answer","text":"No referral is required. You can book directly, and we also welcome referrals from area OB-GYNs and primary care providers. Confirm your insurance benefits, as fertility coverage varies by plan."}},
        {"@type":"Question","name":"When should I schedule a fertility consultation?","acceptedAnswer":{"@type":"Answer","text":"Consider an evaluation if you are under 35 and have tried to conceive for 12 months, or 6 months if you are 35 or older. Reach out sooner with irregular cycles, PCOS or endometriosis, prior losses, or to plan ahead with egg freezing."}}
      ]
    }
  ]
}
</script>
'''

block = PREFIX + "\n" + INNER + "\n</div>"
build_v2.write_pair("dayton-fertility-center",
  "Dayton Fertility Clinic in Centerville | IVF, IUI &amp; Egg Freezing | SpringCreek",
  "Dayton fertility specialists in Centerville, OH. IVF, IUI &amp; egg freezing with an on-site IVF laboratory from board-certified physicians. (937) 458-5084.",
  "https://www.springcreekfertility.com/dayton-fertility-center/", block)
print("Dayton (Centerville) Brand v2 page written (standalone + elementor).")
